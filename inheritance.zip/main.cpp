#include "single_inheritance.h"
#include "Multiple_Inheritances.h"
#include "multilevel_inheritance.h"
#include "Hierarchical_Inheritance.h"
#include "Hybrid_Inheritance.h"



int main()
{

    Student a(40125933,19,"rasoul","09395306094","8raha60@gmail.com");
    student a1(20);
    sportCar a2(120,4,12.5);
    salesPerson1 a3("edari","40125933",20000);
    salesManager a4("edari","ap","122356",50000,5);
    cout<<a4.get();

}