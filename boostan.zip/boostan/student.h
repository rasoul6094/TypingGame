#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include "person.h"
#include "course.h"

class Student : public Person {
public:
    Student(std::string id, std::string first_name, std::string last_name, int year_of_entry);
    Student(std::string id, std::string first_name, std::string last_name, int year_of_entry, int max_courses);
    ~Student();
    void add_course(Course* c);
    void remove_course(Course* c);
    void display() override;

private:
    Course** courses;
    int num_courses;
    int max_courses;
};

#endif
