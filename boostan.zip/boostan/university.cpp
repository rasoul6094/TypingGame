#include <iostream>
#include "university.h"

University& University::get_instance() {
    static University instance;
    return instance;
}

void University::add_student(std::string id, std::string first_name, std::string last_name, int year_of_entry) {
    if (num_students < 100) {
        students[num_students] = new Student(id, first_name, last_name, year_of_entry);
        num_students++;
    }
    else {
        std::cout << "Error: Maximum number of students reached.\n";
    }
}

void University::add_teacher(std::string id, std::string first_name, std::string last_name, int year_of_entry) {
    if (num_teachers < 50) {
        teachers[num_teachers] = new Teacher(id, first_name, last_name, year_of_entry);
        num_teachers++;
    }
    else {
        std::cout << "Error: Maximum number of teachers reached.\n";
    }
}

void University::add_course(std::string name, int teacher_id) {
    if (num_courses < 50) {
        Teacher* t = find_teacher(std::to_string(teacher_id));
        if (t) {
            courses[num_courses] = new Course(num_courses + 1, name, teacher_id);
            num_courses++;
            t->add_course(courses[num_courses-1]);
        }
        else {
            std::cout << "Error: Teacher with ID " << teacher_id << " not found.\n";
        }
    }
    else {
        std::cout << "Error: Maximum number of courses reached.\n";
    }
}

Student* University::find_student(std::string id) {
    for (int i = 0; i < num_students; i++) {
        if (students[i]->get_id() == id) {
            return students[i];
        }
    }
    return nullptr;
}

Teacher* University::find_teacher(std::string id) {
    for (int i = 0; i < num_teachers; i++) {
        if (teachers[i]->get_id() == id) {
            return teachers[i];
        }
    }
    return nullptr;
}

Course* University::find_course(int id) {
    for (int i = 0; i < num_courses; i++) {
        if (courses[i]->get_id() == id) {
            return courses[i];
        }
    }
    return nullptr;
}

void University::display_students() {
    std::cout << "Students:\n";
    if (num_students == 0) {
        std::cout << "None\n";
    }
    else {
        for (int i = 0; i < num_students; i++) {
            students[i]->display();
            std::cout << "\n";
        }
    }
}

void University::display_teachers() {
    std::cout << "Teachers:\n";
    if (num_teachers == 0) {
        std::cout << "None\n";
    }
    else {
        for (int i = 0; i < num_teachers; i++) {
            teachers[i]->display();
            std::cout << "\n";
        }
    }
}

void University::display_courses() {
    std::cout << "Courses:\n";
    if (num_courses == 0) {
        std::cout << "None\n";
    }
    else {
        for (int i = 0; i < num_courses; i++) {
            courses[i]->display();
            std::cout << "\n";
        }
    }
}

University::University() : num_students(0), num_teachers(0), num_courses(0) {
    students = new Student*[100];
    teachers = new Teacher*[50];
    courses = new Course*[50];
}

