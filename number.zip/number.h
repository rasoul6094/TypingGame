
#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;
class number
{
private:
    char *num;
    int size;

public:
    number();
    explicit number(int _num);
    number(const char *str, int sz);
    number(const string str, int sz);
    number(const number &other);
    ~number();
    void operator=(const number &other);
    void operator=(const int &other);
    number operator+(const number &n) const;
    char operator+(const int &index) const;
    // friend char operator+(int index ,const number &num);
    number operator-(const number &n) const;
    // friend number operator-(const int n,const number& num) ;
    // friend number operator-(const number& num,const int n) ;
    const number operator*(const number &other) const;
    char operator[](int index) const;
    operator string() const;
    friend istream &operator>>(istream &is, number &num);
    friend ostream &operator<<(ostream &os, const number &num);
    number &operator++();
    number operator++(int);
    number &operator+=(const number &other);
//    friend number& operator+=(number& num,int other);
    number &operator-=(const number &other);
    // number &operator-=(int &other);
    bool operator==(const number &other) const;
    bool operator>(const number &other) const;
    bool operator>(int &temp) const;
    void operator<<(int shift);
    const number operator%(const number &other) const;
    // const number operator%(int &temp) const;
    operator long long int() const;
    

private:
    void divide(const number &other, number &quotient, number &remainder) const;
};

