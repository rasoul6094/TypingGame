#ifndef UNIVERSITY_H
#define UNIVERSITY_H

#include <string>
#include "student.h"
#include "teacher.h"
#include "course.h"

class University {
public:
    static University& get_instance();
    void add_student(std::string id, std::string first_name, std::string last_name, int year_of_entry);
    void add_teacher(std::string id, std::string first_name, std::string last_name, int year_of_entry);
    void add_course(std::string name, int teacher_id);
    Student* find_student(std::string id);
    Teacher* find_teacher(std::string id);
    Course* find_course(int id);
    void display_students();
    void display_teachers();
    void display_courses();

private:
    University(); // private constructor to prevent instantiation
    University(University const&) = delete; // delete copy constructor
    void operator=(University const&) = delete; // delete assignment operator
    Student** students;
    int num_students;
    Teacher** teachers;
    int num_teachers;
    Course** courses;
    int num_courses;
};

#endif
