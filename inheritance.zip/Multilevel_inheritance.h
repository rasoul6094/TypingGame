#ifndef Multilevel_inheritance
#define Multileve_inheritance
#include <iostream>
#include <string>
using namespace std;
class vehicle
{
protected:
    float fuel_capacty;

public:
    vehicle(float _fuel_capacty)
    {
        fuel_capacty = _fuel_capacty;
    }
};

class car : public vehicle
{
protected:
    int number_of_wheels;

public:
    car(int _number_of_wheels, float _fuel_capacty)
        : vehicle(_fuel_capacty)
    {
        number_of_wheels = _number_of_wheels;
    }
};

class sportCar : public car
{
protected:
    int top_speed;

public:
    sportCar(int _top_Speed, int _number_of_wheels, float _fuel_capacty)
        : car(_number_of_wheels, _fuel_capacty)
    {
        top_speed = _top_Speed;
    }
};

#endif