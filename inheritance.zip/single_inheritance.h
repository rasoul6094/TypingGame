#ifndef single_inheritance
#define single_inheritance
#include <iostream>
#include <string>
using namespace std;
class Person
{
protected:
    string name, phone_number, email_address;

public:
    Person(string _name, string _phone_number, string _email_address)
    {
        name = _name;
        phone_number = _phone_number;
        email_address = _email_address;
    }
};

class Student : public Person
{
protected:
    long long int student_number;
    float average_mark;

public:
    Student(long long int _student_number, float _average_mark, string _name, string _phone_number, string _email_address)
        : Person(_name, _phone_number, _email_address)
    {
        student_number = _student_number;
        average_mark = _average_mark;
    }
};

#endif