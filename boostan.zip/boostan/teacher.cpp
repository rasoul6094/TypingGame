#include <iostream>
#include "teacher.h"

Teacher::Teacher(std::string id, std::string first_name, std::string last_name, int year_of_entry)
    : Person(id, first_name, last_name, year_of_entry), num_courses(0), max_courses(0) {}

Teacher::Teacher(std::string id, std::string first_name, std::string last_name, int year_of_entry, int max_courses)
    : Person(id, first_name, last_name, year_of_entry), num_courses(0), max_courses(max_courses) {
    courses = new Course*[max_courses];
}

Teacher::~Teacher() {
    delete[] courses;
}

void Teacher::add_course(Course* c) {
    if (num_courses < max_courses) {
        courses[num_courses] = c;
        num_courses++;
    }
    else {
        std::cout << "Error: Teacher is already teaching the maximum number of courses.\n";
    }
}

void Teacher::remove_course(Course* c) {
    for (int i = 0; i < num_courses; i++) {
        if (courses[i] == c) {
            // move all elements after i back by one
            for (int j = i + 1; j < num_courses; j++) {
                courses[j-1] = courses[j];
            }
            num_courses--;
            break;
        }
    }
}

void Teacher::display() {
    std::cout << "ID: " << id << "\n";
    std::cout << "Name: " << first_name << " " << last_name << "\n";
    std::cout << "Year of entry: " << year_of_entry << "\n";
    std::cout << "Courses:\n";
    if (num_courses == 0) {
        std::cout << "None\n";
    }
    else {
        for (int i = 0; i < num_courses; i++) {
            std::cout << "- ";
            if (courses[i]) {
                std::cout << courses[i]->get_name() << "\n";
            }
            else {
                std::cout << "None\n";
            }
        }
    }
}
