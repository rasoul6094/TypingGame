#include <iostream>
#include "course.h"

Course::Course(int id, std::string name, int teacher_id)
    : id(id), name(name), num_students(0), max_students(0) {
    teacher = new Teacher("", "", "", 0); // create a temporary empty teacher object
    teacher->add_course(this);
}

Course::~Course() {
    delete teacher; // delete the teacher object created in the constructor
    delete[] students;
}

void Course::add_student(Student* s) {
    if (num_students < max_students) {
        students[num_students] = s;
        num_students++;
        s->add_course(this);
    }
    else {
        std::cout << "Error: Course is already full.\n";
    }
}

void Course::remove_student(Student* s) {
    for (int i = 0; i < num_students; i++) {
        if (students[i] == s) {
            // move all elements after i back by one
            for (int j = i + 1; j < num_students; j++) {
                students[j-1] = students[j];
            }
            num_students--;
            s->remove_course(this);
            break;
        }
    }
}

int Course::get_id() {
    return id;
}

std::string Course::get_name() {
    return name;
}

Teacher* Course::get_teacher() {
    return teacher;
}

Student** Course::get_students() {
    return students;
}

int Course::get_num_students() {
    return num_students;
}

void Course::display(){
    std::cout << "ID: " << id << "\n";
    std::cout << "Name: " << name << "\n";
    std::cout << "Teacher: " << teacher->get_first_name() << " " << teacher->get_last_name() << "\n";
    std::cout << "Students:\n";
    if (num_students == 0) {
        std::cout << "None\n";
    }
    else {
        for (int i = 0; i < num_students; i++) {
            std::cout << "- ";
            if (students[i]) {
                std::cout << students[i]->get_first_name() << " " << students[i]->get_last_name() << "\n";
            }
            else {
                std::cout << "None\n";
            }
        }
    }
}
