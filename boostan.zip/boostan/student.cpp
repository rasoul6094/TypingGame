#include <iostream>
#include "student.h"

Student::Student(std::string id, std::string first_name, std::string last_name, int year_of_entry)
    : Person(id, first_name, last_name, year_of_entry), num_courses(0), max_courses(0) {}

Student::Student(std::string id, std::string first_name, std::string last_name, int year_of_entry, int max_courses)
    : Person(id, first_name, last_name, year_of_entry), num_courses(0), max_courses(max_courses) {
    courses = new Course*[max_courses];
}

Student::~Student() {
    delete[] courses;
}

void Student::add_course(Course* c) {
    if (num_courses < max_courses) {
        courses[num_courses] = c;
        num_courses++;
    }
    else {
        std::cout << "Error: Student is already enrolled in the maximum number of courses.\n";
    }
}

void Student::remove_course(Course* c) {
    for (int i = 0; i < num_courses; i++) {
        if (courses[i] == c) {
            // move all elements after i back by one
            for (int j = i + 1; j < num_courses; j++) {
                courses[j-1] = courses[j];
            }
            num_courses--;
            break;
        }
    }
}

void Student::display() {
    std::cout << "ID: " << id << "\n";
    std::cout << "Name: " << first_name << " " << last_name << "\n";
    std::cout << "Year of entry: " << year_of_entry << "\n";
    std::cout << "Courses:\n";
    if (num_courses == 0) {
        std::cout << "None\n";
    }
    else {
        for (int i = 0; i < num_courses; i++) {
            std::cout << "- ";
            if (courses[i]) {
                std::cout << courses[i]->get_name() << " (" << courses[i]->get_teacher()->get_first_name() << " " << courses[i]->get_teacher()->get_last_name() << ")\n";
            }
            else {
                std::cout << "None\n";
            }
        }
    }
}
