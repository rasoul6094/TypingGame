#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person {
public:
    Person(std::string id, std::string first_name, std::string last_name, int year_of_entry);
    virtual void display() = 0;
    std::string get_id();
    std::string get_first_name();
    std::string get_last_name();
    int get_year_of_entry();

protected:
    std::string id;
    std::string first_name;
    std::string last_name;
    int year_of_entry;
};

#endif
