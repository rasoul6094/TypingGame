#include "person.h"

Person::Person(std::string id, std::string first_name, std::string last_name, int year_of_entry)
    : id(id), first_name(first_name), last_name(last_name), year_of_entry(year_of_entry) {}

std::string Person::get_id() {
    return id;
}

std::string Person::get_first_name() {
    return first_name;
}

std::string Person::get_last_name() {
    return last_name;
}

int Person::get_year_of_entry() {
    return year_of_entry;
}
