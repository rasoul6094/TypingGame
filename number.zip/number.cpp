#include "number.h"

number::number()
{
    num = new char[2];
    num[0] = '0';
    num[1] = '\0';
    size = 1;
}
//===============================================================================
number::number(int _num)
{
    string tmp = to_string(_num);
    size = tmp.length();
    strcpy(num, tmp.c_str());
}
//===============================================================================
number::number(const char *str, int sz)
{
    sz = strlen(str);
    num = new char[sz + 1];
    strcpy(num, str);
    size = sz;
}
//===============================================================================
number::number(const string str, int sz)
{
    sz = str.length();
    num = new char[sz + 1];
    strcpy(num, str.c_str());
    size = sz;
}
//===============================================================================
number::number(const number &other)
{
    num = new char[other.size + 1];
    strcpy(num, other.num);
    size = other.size;
}
//===============================================================================
number::~number()
{
    delete[] num;
}
//===================================================================
void number::operator=(const number &other)
{
    delete[] num;
    num = new char[other.size + 1];
    strcpy(num, other.num);
    size = other.size;
}
//===============================================================================
void number::operator=(const int &other)
{
    delete[] num;
    string tmp = to_string(other);
    int len = tmp.length();
    num = new char[len + 1];
    strcpy(num, tmp.c_str());
    size = len;
}
//=====================================================================
number number::operator+(const number &n) const
{
    int max_size = std::max(size, n.size);
    char *result = new char[max_size + 10];
    result[max_size] = '\0';
    int i = size - 1, j = n.size - 1, k = max_size - 1, carry = 0;
    while (i >= 0 || j >= 0 || carry > 0)
    {
        int sum = carry;
        if (i >= 0)
            sum += num[i--] - '0';
        if (j >= 0)
            sum += n.num[j--] - '0';
        result[k--] = (sum % 10) + '0';
        carry = sum / 10;
    }
    return number(result, max_size);
}
//===============================================================================
// char number::operator+(const int &index) const
// {
//     if (size > index)
//         return num[index];
//     else
//     {
//         cout << "index is wrong" << endl;
//         return '\0';
//     }
// }
// char operator+(int index, const number &num)
// {
//     if (num.size > index)
//         return num[index];
//     else
//     {
//         cout << "index is wrong" << endl;
//         return '\0';
//     }
// }
//=====================================================================
number number::operator-(const number &n) const
{
    if (*this >= n)
    {
        int max_size = std::max(size, n.size);
        char *result = new char[max_size + 1];
        result[max_size] = '\0';
        int i = size - 1, j = n.size - 1, k = max_size - 1, borrow = 0;
        while (i >= 0 || j >= 0)
        {
            int diff = borrow;
            if (i >= 0)
                diff += num[i--] - '0';
            if (j >= 0)
                diff -= (n.num[j--] - '0');
            if (diff < 0)
            {
                diff += 10;
                borrow = -1;
            }
            else
            {
                borrow = 0;
            }
            result[k--] = diff + '0';
        }
        while (result[0] == '0' && strlen(result) > 1)
        {
            ++result;
            --max_size;
        }
        return number(result, max_size);
    }
    else
    {
        int max_size = std::max(size, n.size);
        char *result = new char[max_size + 1];
        result[max_size] = '\0';
        int i = n.size - 1, j = size - 1, k = max_size - 1, borrow = 0;
        while (i >= 0 || j >= 0)
        {
            int diff = borrow;
            if (i >= 0)
                diff += n.num[i--] - '0';
            if (j >= 0)
                diff -= (num[j--] - '0');
            if (diff < 0)
            {
                diff += 10;
                borrow = -1;
            }
            else
            {
                borrow = 0;
            }
            result[k--] = diff + '0';
        }
        while (result[0] == '0' && strlen(result) > 1)
        {
            ++result;
            --max_size;
        }
        return number(result, max_size);
    }
}
//===============================================================================
// number operator-(const int &n, const number &num)
// {
//     number _num(n);
//     return _num - num;
// }
// //===============================================================================
// number operator-(const number &num, const int n)
// {
//     number _num(n);
//     return _num - num;
// }
//===================================================================
const number number::operator*(const number &other) const
{
    int len1 = size;
    int len2 = other.size;
    int len = len1 + len2;
    char *res = new char[len + 1];
    for (int i = 0; i < len; i++)
    {
        res[i] = '0';
    }
    int carry = 0;
    for (int i = len1 - 1; i >= 0; i--)
    {
        carry = 0;
        for (int j = len2 - 1; j >= 0; j--)
        {
            int x = num[i] - '0';
            int y = other.num[j] - '0';
            int sum = x * y + carry + (res[i + j + 1] - '0');
            carry = sum / 10;
            res[i + j + 1] = (sum % 10) + '0';
        }

        while (carry)
        {
            res[i--] += carry;
            carry = (res[i + 1] - '0') / 10;
            res[i + 1] = (res[i + 1] - '0') % 10 + '0';
        }
    }
    while (len > 1 && res[0] == '0')
    {
        for (int i = 0; i < len - 1; i++)
        {
            res[i] = res[i + 1];
        }
        len--;
    }

    res[len] = '\0';
    number result(res, len);
    delete[] res;
    return result;
}
//===========================================================================
char number::operator[](int index) const
{
    if (index >= size || index < 0)
    {
        return '\0';
    }
    else
    {
        return num[index];
    }
}
//============================================================================
number::operator string() const
{
    return string(num);
}
//============================================================================
istream &operator>>(istream &is, number &_num)
{
    string str;
    is >> str;
    int len = str.length();
    char *res = new char[len + 1];
    strcpy(res, str.c_str());
    delete[] _num.num;
    _num.num = res;
    _num.size = len;
    return is;
}
//===============================================================================
ostream &operator<<(ostream &os, const number &_num)
{
    for (int i = 0; i < strlen(_num.num); i++)
        os << _num.num[i];

    return os;
}
//===============================================================================
number &number::operator++()
{
    *this = *this + number("1", 1);
    return *this;
}
//===============================================================================
number number::operator++(int)
{
    number temp(*this);
    ++(*this);
    return temp;
}
//===============================================================================
number &number::operator+=(const number &other)
{
    *this = *this + other;
    return *this;
}
//===============================================================================
number& operator+=(number& num,int other)
{   
    
     num=num+(number)other;
    return num;
}
//===============================================================================
number &number::operator-=(const number &other)
{
    *this = *this - other;
    return *this;
}
//===============================================================================
// number &number::operator-=(int &other)
// {
//     *this = *this - (number)other;
//     return *this;
// }
//===============================================================================
bool number::operator==(const number &other) const
{
    if (size != other.size)
    {
        return false;
    }
    for (int i = 0; i < size; i++)
    {
        if (num[i] != other.num[i])
        {
            return false;
        }
    }
    return true;
}
//===============================================================================
bool number::operator>(const number &other) const
{
    if (size > other.size)
    {
        return true;
    }
    else if (size < other.size)
    {
        return false;
    }
    else
    {
        for (int i = 0; i < size; i++)
        {
            int x = num[i] - '0';
            int y = other.num[i] - '0';
            if (x > y)
            {
                return true;
            }
            else if (x < y)
            {
                return false;
            }
        }
        return false;
    }
}
//===============================================================================
bool number::operator>(int &temp) const
{
    number other = (number)temp;

    if (size > other)
    {
        return true;
    }
    else if (size < other.size)
    {
        return false;
    }
    else
    {
        for (int i = 0; i < size; i++)
        {
            int x = num[i] - '0';
            int y = other.num[i] - '0';
            if (x > y)
            {
                return true;
            }
            else if (x < y)
            {
                return false;
            }
        }
        return false;
    }
}
//===============================================================================
void number::operator<<(int shift)
{
    if (shift == 0)
    {
        return;
    }
    char *res = new char[size + shift + 1];
    for (int i = 0; i < shift; i++)
    {
        res[i] = '0';
    }
    for (int i = shift; i < size + shift; i++)
    {
        res[i] = num[i - shift];
    }
    res[size + shift] = '\0';
    delete[] num;
    num = res;
    size += shift;
}
//===============================================================================
const number number::operator%(const number &other) const
{
    number quotient, remainder;
    divide(other, quotient, remainder);
    return remainder;
}
//===============================================================================
// const number number::operator%(int &temp) const
// {
//     number other = (number)temp;
//     number quotient, remainder;
//     divide(other, quotient, remainder);
//     return remainder;
// }
//===============================================================================
number::operator long long int() const
{
    long long int result = 0;
    for (int i = 0; i < size; i++)
    {
        result = result * 10 + (num[i] - '0');
        result = result % 9223372036854775807;
    }
    return result;
}
//===============================================================================
void number::divide(const number &other, number &quotient, number &remainder) const
{
    int len1 = size;
    int len2 = other.size;
    char *res = new char[len1 + 1];
    char *divisor = new char[len1 + 1];
    char *dividend = new char[len1 + 1];
    strcpy(dividend, num);
    for (int i = 0; i < len1 - len2; i++)
    {
        divisor[i] = '0';
    }
    for (int i = 0; i < len2; i++)
    {
        divisor[len1 - len2 + i] = other.num[i];
    }
    divisor[len1] = '\0';
    quotient = number("0", 1);
    remainder = number(dividend, len2);
    while (remainder > other || remainder == other)
    {
        int i = 0;
        number temp(divisor, len1);

        while ((temp * number(to_string(i), to_string(i).length())) <= remainder)
        {
            ++i;
        }
        i--;

        quotient += number(to_string(i), to_string(i).length());
        remainder -= temp * number(to_string(i), to_string(i).length());
    }
    delete[] res;
    delete[] divisor;
    delete[] dividend;
}
//===============================================================================
