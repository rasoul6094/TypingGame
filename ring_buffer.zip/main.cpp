#include <iostream>
#include "ring_buffer.h"
using namespace std;

int main()
{
    RingBuffer<int, 10> buffer;

    try
    {
        for (int i = 0; i < 10; i++)
            buffer.push(i);

        buffer.display();

        while (!buffer.isEmpty())
            cout << "[" << buffer.pop() << "]"<< " ";

        cout << "were poped from buffer" << endl;

        for (int i = 25; i < 50; i++)
            buffer.push(i);

        while (!buffer.isEmpty())
            cout << buffer.pop() << " ";

        cout << endl;
    }

    catch (const exception &e)
    {
        cout << "Exception : " << e.what() << endl;
    }

    buffer.display();
}