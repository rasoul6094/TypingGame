#include "ring_buffer.h"

template <typename T, int bufferSize>
RingBuffer<T, bufferSize>::RingBuffer()
{
    buffer = new T[bufferSize];
    head = 0;
    tali = 0;
    count = 0;
    isFull = false;
}

template <typename T, int bufferSize>
RingBuffer<T, bufferSize>::~RingBuffer()
{
    delete[] buffer;
}

template <typename T, int bufferSize>
void RingBuffer<T, bufferSize>::push(const T &data)
{
    if (isFull)
        throw std::overflow_error("ring buffer ia full");

    buffer[head] = data;
    head = (head + 1) % bufferSize;
    count++;

    if (head == tali)
        isFull = true;
}

template <typename T, int bufferSize>
T RingBuffer<T, bufferSize>::pop()
{
    if (isEmpty())
        throw std::underflow_error("ring buffer is empty");
    T data = buffer[tali];
    isFull = false;
    tali = (tali + 1) % bufferSize;
    count--;
    return data;
}

template <typename T, int bufferSize>
bool RingBuffer<T, bufferSize>::isEmpty() const
{
    return (!isFull && (head == tali));
}

template <typename T, int bufferSize>
bool RingBuffer<T, bufferSize>::isFully() const
{
    return isFull;
}

template <typename T, int bufferSize>
void RingBuffer<T, bufferSize>::display()
{
    if (count != 0)
    {
        for (int i = 0; i < count; i++)
            std::cout << "[" << buffer[i] << "]" << " ";

        std::cout << "are in buffer" << std::endl;
    }
    else
        std::cout << "ring buffer is empty" << std::endl;
}