#ifndef RING_BUFFER
#define RING_BUFFER
#include <iostream>
#include <stdexcept>

template <typename T, int bufferSize>
class RingBuffer
{
public:
    RingBuffer();

    ~RingBuffer();

    void push(const T &data);

    T pop();

    bool isEmpty() const;

    bool isFully() const;

    void display();

private:
    int count;
    T *buffer;
    int head, tali;
    bool isFull;
};

#endif