#ifndef COURSE_H
#define COURSE_H
#include <string>
#include "teacher.h"
#include "student.h"

class Course {
public:
    Course(int id, std::string name, int teacher_id);
    ~Course();
    void add_student(Student* s);
    void remove_student(Student* s);
    int get_id();
    std::string get_name();
    Teacher* get_teacher();
    Student** get_students();
    int get_num_students();
    void display();

private:
    int id;
    std::string name;
    Teacher* teacher;
    Student** students;
    int num_students;
    int max_students;
};

#endif
