#ifndef  Multiple_Inheritances
#define  Multiple_Inheritances
#include <iostream>
#include <string>
using namespace std;
class teacher
{
protected:
    float slary;

public:
    teacher(float _slary)
    {
        slary = _slary;
    }
};

class student
{
protected:
    int gpa;

public:
    student(int _gpa)

    {
        gpa = _gpa;
    }
};

class teacherAssistant : public teacher, public student
{
protected:
    bool hasYektaAccess;

public:
    teacherAssistant(float _salary, int _gpa, bool _hasYektaAccess)
        : teacher(_salary), student(_gpa)
    {
        hasYektaAccess = _hasYektaAccess;
    }
};

#endif