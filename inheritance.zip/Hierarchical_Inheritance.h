#ifndef Hierarchical_Inheritance
#define Hierarchical_Inheritance
#include <iostream>
#include <string>
using namespace std;
class employee1
{
protected:
    float slary;
    string id;

public:
    employee1(string _id, float _slary)
    {
        slary = _slary;
        id = _id;
    }
};

class manager1 : public employee1
{
protected:
    string department;

public:
    manager1(string _department, string _id, float _slary)
        : employee1(_id, _slary)
    {
        department = _department;
    }
};

class salesPerson1 : public employee1
{
protected:
    string commission;

public:
    salesPerson1(string _commission, string _id, float _slary)
        : employee1(_id, _slary)
    {
        commission = _commission;
    

    }
};

#endif