#ifndef Hybrid_Inheritance
#define Hybrid_Inheritance
#include <iostream>
#include <string>
using namespace std;
class employee
{
protected:
    float slary;
    string id;

public:
    employee(string _id, float _slary)
    {
        slary = _slary;
        id = _id;
    }
 
    string get()
    {
        return id;
    }
};

class manager : virtual public employee
{
protected:
    string department;

public:
    manager(string _department, string _id, float _slary)
        : manager::employee(_id, _slary)
    {
        department = _department;
    }
};

class salesPerson : virtual public employee
{
protected:
    string commission;

public:
    salesPerson(string _commission, string _id, float _slary)
        : salesPerson::employee(_id, _slary)
    {
        commission = _commission;
    }
};


class salesManager:public manager , public salesPerson
{
 protected:
 int sales_count;
 public:
 salesManager(string _department,string _commission, string _id, float _slary ,int _sales_count=0 )
 :employee( _id,  _slary) ,manager( _department, _id,  _slary),salesPerson(_commission, _id, _slary)
 {
    sales_count=_sales_count;
 }
};


#endif