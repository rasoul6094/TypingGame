#ifndef TEACHER_H
#define TEACHER_H
#include <string>
#include "course.h"
#include "person.h"


class Teacher : public Person {
public:
    Teacher(std::string id, std::string first_name, std::string last_name, int year_of_entry);
    Teacher(std::string id, std::string first_name, std::string last_name, int year_of_entry, int max_courses);
    ~Teacher();
    void add_course(Course * c);
    void remove_course(Course* c);
    void display() override;

private:
    Course** courses;
    int num_courses;
    int max_courses;
};

#endif
