#include "university.h"

int main() {
    // create an instance of the university
    University& uni = University::get_instance();

    // add some students, teachers, and courses
    uni.add_student("1001", "Alice", "Smith", 2020);
    uni.add_student("1002", "Bob", "Jones", 2020);
    uni.add_teacher("2001", "Carol", "Brown", 2015);
    uni.add_teacher("2002", "Dave", "Lee", 2018);
    uni.add_course("Math", 2001);
    uni.add_course("English", 2002);

    // find some objects by ID
    Student* s = uni.find_student("1001");
    Teacher* t = uni.find_teacher("2001");
    Course* c = uni.find_course(1);

    // add and remove students from courses
    c->add_student(s);
    c->add_student(uni.find_student("1002"));
    c->display();
    c->remove_student(s);
    c->display();

    // add and remove courses from teachers
    t->add_course(c);
    t->display();
    t->remove_course(c);
    t->display();

    // display all objects
    uni.display_students();
    uni.display_teachers();
    uni.display_courses();

    return 0;
}
